/*
Configurations
Credits: original code by Dacal, Matchstic & Junesiphone
*/

var Clock = "24h";  // choose between "12h" or "24h"
var Lang = "en";   // choose between "en", "ca", "fr", "de", "it", or "cz"
