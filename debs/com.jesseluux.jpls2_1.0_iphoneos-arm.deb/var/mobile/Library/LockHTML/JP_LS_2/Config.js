var time = "24h";  // choose between "12h" or "24h"
var blur = true; // choose between true and false, this changes the text shadow to either be blurred or not
