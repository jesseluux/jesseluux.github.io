var time = "24h";  // choose between "12h" or "24h"
